


document.getElementById("t1button").addEventListener("click", spacetheme);
document.getElementById("t2button").addEventListener("click", colorfultheme);
document.getElementById("t3button").addEventListener("click", greentheme);

function spacetheme() { 
    document.getElementById("change").href = "stylesdark.css"
}

function colorfultheme() { 
    document.getElementById("change").href = "stylescolorful.css"
}

function greentheme() { 
    document.getElementById("change").href = "stylesgreen.css"
}



